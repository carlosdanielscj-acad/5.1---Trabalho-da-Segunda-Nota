package com.mycompany.bibliotecaapp;

public class BibliotecaApp {
    public static void main(String[] args) {
        // Cria e exibe a janela CadastroDeLivro
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                CadastroLivro livroFrame = new CadastroLivro();
                livroFrame.setVisible(true);
            }
        });

        // Cria e exibe a janela CadastroDeUsuario
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                CadastroDeUsuario usuarioFrame = new CadastroDeUsuario();
                usuarioFrame.setVisible(true);
            }
        });

        // Cria e exibe a janela RealizarEmprestimo
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                RealizarEmprestimo emprestimoFrame = new RealizarEmprestimo();
                emprestimoFrame.setVisible(true);
            }
        });
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bibliotecapro;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BibliotecaPro {

    private static final String URL = "jdbc:mysql://localhost:3306/bibliotecaProDB";
    private static final String USER = "root";  // Seu usu�rio do MySQL
    private static final String PASSWORD = "";  // Sua senha do MySQL

    public static void main(String[] args) {
        try {
            // Testando conex�o com o banco de dados
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conex�o realizada com sucesso!");
            connection.close();
        } catch (SQLException e) {
            System.out.println("Erro ao conectar ao banco de dados: " + e.getMessage());
        }

        // Inicializa e exibe a janela principal BibliotecaPro
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BibilotecaProJanela().setVisible(true); // Torna a janela principal vis�vel
            }
        });
    }
}